from mage_ai.data_cleaner.transformer_actions.base import BaseAction
from mage_ai.data_cleaner.transformer_actions.constants import ActionType, Axis
from mage_ai.data_cleaner.transformer_actions.utils import build_transformer_action
from pandas import DataFrame
import pandas as pd
if 'transformer' not in globals():
    from mage_ai.data_preparation.decorators import transformer
if 'test' not in globals():
    from mage_ai.data_preparation.decorators import test


@transformer
def execute_transformer_action(dfs: list, *args, **kwargs) -> list:
    """
    Execute Transformer Action: ActionType.DROP_DUPLICATE

    Docs: https://docs.mage.ai/guides/transformer-blocks#drop-duplicates
    """
    tables = kwargs['tables'] 
    mapping = {}  
    tablas = dict(zip(tables, dfs))

    table_name = 'PRODUCTS'
    df_products = tablas[table_name]

    mask_desconocido = df_products['PRODUCT_NAME'].str.lower().str.strip() == 'desconocido'

    desconocido_rows = df_products[mask_desconocido]

    df_without_desconocido = df_products[~mask_desconocido]

    min_id_per_name = df_without_desconocido.groupby('PRODUCT_NAME')['PRODUCT_ID'].min().to_dict()
    
    def map_product_id(row):
        min_id = min_id_per_name.get(row['PRODUCT_NAME'])
        if row['PRODUCT_ID'] != min_id:
            mapping[row['PRODUCT_ID']] = min_id
        return row
    
    df_without_desconocido.apply(map_product_id, axis=1)
    df_without_desconocido = df_without_desconocido.sort_values(by='PRODUCT_ID', ascending=True)
    
    count_before = df_products.shape[0]
    action = build_transformer_action(
        df_without_desconocido,
        action_type=ActionType.DROP_DUPLICATE,
        arguments=['PRODUCT_NAME'],
        axis=Axis.ROW,
        options={'keep': 'first'},
    )
    result_products_without_desconocido = BaseAction(action).execute(df_without_desconocido)

    df_desconocido_deduplicated = desconocido_rows.drop_duplicates(subset='PRODUCT_ID', keep='first')

    final_result_products = pd.concat([result_products_without_desconocido, df_desconocido_deduplicated])

    final_result_products = final_result_products.sort_index()

    tablas[table_name] = final_result_products
    count_after = final_result_products.shape[0]
    print("PRODUCTS - registros antes:", count_before, "después:", count_after, "eliminados:", count_before - count_after)
    del df_products

    table_name = 'ORDER_PRODUCTS'
    df_order_products = tablas[table_name]
    df_order_products['PRODUCT_ID'] = df_order_products['PRODUCT_ID'].apply(lambda x: mapping.get(x, x))
    tablas[table_name] = df_order_products
    del df_order_products

    table_name = 'ORDERS'
    df_orders = tablas[table_name]
    count_before = df_orders.shape[0]
    action = build_transformer_action(
        df_orders,
        action_type=ActionType.DROP_DUPLICATE,
        arguments=['ORDER_ID'],
        axis=Axis.ROW,
        options={'keep': 'first'},
    )
    result_orders = BaseAction(action).execute(df_orders)
    count_after = result_orders.shape[0]
    print("ORDERS - registros antes:", count_before, "después:", count_after, "eliminados:", count_before - count_after)
    tablas[table_name] = result_orders
    del df_orders

    return list(tablas.values())

@test
def test_output(output, *args) -> None:
    """
    Template code for testing the output of the block.
    """
    assert output is not None, 'The output is undefined'

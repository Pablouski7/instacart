from mage_ai.data_cleaner.transformer_actions.base import BaseAction
from mage_ai.data_cleaner.transformer_actions.constants import ActionType, Axis
from mage_ai.data_cleaner.transformer_actions.utils import build_transformer_action
from pandas import DataFrame

if 'transformer' not in globals():
    from mage_ai.data_preparation.decorators import transformer
if 'test' not in globals():
    from mage_ai.data_preparation.decorators import test


@transformer
def execute_transformer_action(dfs: list, *args, **kwargs) -> list:
    """
    Execute Transformer Action: ActionType.REFORMAT

    Docs: https://docs.mage.ai/guides/transformer-blocks#reformat-values

    """
    tables = kwargs['tables'] 

    for i, df in enumerate(dfs):
        string_columns = df.select_dtypes(include=['object']).columns.tolist()
        
        if string_columns:
            action_trim = build_transformer_action(
                df,
                action_type=ActionType.REFORMAT,
                arguments=string_columns,
                axis=Axis.COLUMN,
                options={'reformat': 'trim'},
            )
            df = BaseAction(action_trim).execute(df)
            
            action_lower = build_transformer_action(
                df,
                action_type=ActionType.REFORMAT,
                arguments=string_columns,
                axis=Axis.COLUMN,
                options={
                    'reformat': 'caps_standardization',
                    'capitalization': 'lowercase'
                },
            )
            df = BaseAction(action_lower).execute(df)
        
        dfs[i] = df

    return dfs


@test
def test_output(output, *args) -> None:
    """
    Template code for testing the output of the block.
    """
    assert output is not None, 'The output is undefined'

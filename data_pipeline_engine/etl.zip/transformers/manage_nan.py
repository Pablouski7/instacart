from mage_ai.data_cleaner.transformer_actions.constants import ImputationStrategy
from mage_ai.data_cleaner.transformer_actions.base import BaseAction
from mage_ai.data_cleaner.transformer_actions.constants import ActionType, Axis
from mage_ai.data_cleaner.transformer_actions.utils import build_transformer_action
from pandas import DataFrame

if 'transformer' not in globals():
    from mage_ai.data_preparation.decorators import transformer
if 'test' not in globals():
    from mage_ai.data_preparation.decorators import test

@transformer
def execute_transformer_action(dfs: list, *args, **kwargs) -> list:
    """
    Execute Transformer Action: ActionType.IMPUTE

    Docs: https://docs.mage.ai/guides/transformer-blocks#fill-in-missing-values
    """

    tables = kwargs['tables']  
    columns_to_impute = {
        'ORDERS': {
            'DAYS_SINCE_PRIOR_ORDER': {
                'strategy': ImputationStrategy.CONSTANT,
                'value': 0 
            }
        },
        'ORDER_PRODUCTS': {
            'ADD_TO_CART_ORDER': {
                'strategy': ImputationStrategy.CONSTANT,
                'value': -1  
            }
        },
        'PRODUCTS': {
            'PRODUCT_NAME': {
                'strategy': ImputationStrategy.CONSTANT,
                'value': 'Desconocido'  
            }
        }
    }

    for i, df in enumerate(dfs):
        table_name = tables[i]  
        if table_name in columns_to_impute:
            for column, config in columns_to_impute[table_name].items():
                nan_count = df[column].isna().sum()
                print(f"Tabla: '{table_name}', Columna: '{column}' -> Nans a rellenar: {nan_count}")

                action = build_transformer_action(
                    df,
                    action_type=ActionType.IMPUTE,
                    arguments=[column],  
                    axis=Axis.COLUMN,
                    options={
                        'strategy': config['strategy'],  
                        'value': config['value']          
                    },
                )
                dfs[i] = BaseAction(action).execute(df)  

    return dfs

@test
def test_output(output, *args) -> None:
    """
    Template code for testing the output of the block.
    """
    assert output is not None, 'The output is undefined'

if 'transformer' not in globals():
    from mage_ai.data_preparation.decorators import transformer
if 'test' not in globals():
    from mage_ai.data_preparation.decorators import test

# Tranformador para crear las tablas de hechos y dimensiones (hecha con ayuda de chatgpt)
@transformer
def transform(dfs: list, *args, **kwargs) -> dict:
    tables = kwargs['tables']
    tablas_actuales = {f'df_{name}': df for name, df in zip(tables, dfs)}
    nuevas_tablas = {}

    df_aisles = tablas_actuales['df_AISLES']
    df_departments = tablas_actuales['df_DEPARTMENTS']
    df_orders = tablas_actuales['df_ORDERS']
    df_order_products = tablas_actuales['df_ORDER_PRODUCTS']
    df_products = tablas_actuales['df_PRODUCTS']
    
    df_dim_day = df_orders[['ORDER_DOW', 'ORDER_HOUR_OF_DAY']].drop_duplicates().reset_index(drop=True)
    df_dim_day['DAY_ID'] = range(1, len(df_dim_day) + 1)
    
    df_dim_day['IS_WEEKEND'] = df_dim_day['ORDER_DOW'].apply(lambda x: True if x in [0, 6] else False)
    
    def get_time_of_day(hour):
        if hour < 12:
            return 'Morning'
        elif hour < 18:
            return 'Afternoon'
        else:
            return 'Evening'
    df_dim_day['TIME_OF_DAY'] = df_dim_day['ORDER_HOUR_OF_DAY'].apply(get_time_of_day)
    
    df_dim_day = df_dim_day[['DAY_ID', 'ORDER_DOW', 'ORDER_HOUR_OF_DAY', 'IS_WEEKEND', 'TIME_OF_DAY']]
    
    df_fact_orders = df_orders.merge(df_dim_day[['DAY_ID', 'ORDER_DOW', 'ORDER_HOUR_OF_DAY']], on=['ORDER_DOW', 'ORDER_HOUR_OF_DAY'], how='left')
    df_fact_orders = df_fact_orders[['ORDER_ID', 'USER_ID', 'DAY_ID', 'ORDER_NUMBER', 'DAYS_SINCE_PRIOR_ORDER']]
    
    df_fact_order_products = df_order_products.copy()
    df_fact_order_products['REORDERED'] = df_fact_order_products['REORDERED'].astype(bool)
    
    df_dim_products = df_products.merge(df_aisles, on='AISLE_ID', how='left')
    df_dim_products = df_dim_products.merge(df_departments, on='DEPARTMENT_ID', how='left')
    df_dim_products = df_dim_products[['PRODUCT_ID', 'PRODUCT_NAME', 'DEPARTMENT', 'AISLE']]
    
    nuevas_tablas['FACT_ORDERS'] = df_fact_orders
    nuevas_tablas['FACT_ORDER_PRODUCTS'] = df_fact_order_products
    nuevas_tablas['DIM_PRODUCTS'] = df_dim_products
    nuevas_tablas['DIM_DAY'] = df_dim_day

    return nuevas_tablas

@test
def test_output(output, *args) -> None:
    """
    Prueba la salida del bloque.
    """
    assert output is not None, 'The output is undefined'

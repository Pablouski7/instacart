from mage_ai.settings.repo import get_repo_path
from mage_ai.io.config import ConfigFileLoader
from mage_ai.io.snowflake import Snowflake
from pandas import DataFrame
from os import path

if 'data_exporter' not in globals():
    from mage_ai.data_preparation.decorators import data_exporter


@data_exporter
def export_data_to_snowflake(nuevas_tablas: dict, *args, **kwargs) -> dict:
    """
    Template for exporting data to a Snowflake warehouse.
    Specify your configuration settings in 'io_config.yaml'.

    Docs: https://docs.mage.ai/design/data-loading#snowflake
    """
    database = 'INSTACART_DB'
    schema = 'CLEAN'
    config_path = path.join(get_repo_path(), 'io_config.yaml')
    config_profile = 'default'

    with Snowflake.with_config(ConfigFileLoader(config_path, config_profile)) as loader:
        for table_name, data in nuevas_tablas.items():
            print(f"Cargando datos de la tabla: {table_name} con dimensiones: {data.shape}")
            loader.export(
                data,
                table_name,
                database,
                schema,
                if_exists='replace',  # Specify resolution policy if table already exists
            )
        loader.commit()
        sentencias_sql = [
            "ALTER TABLE FACT_ORDERS ADD CONSTRAINT PK_FACT_ORDERS PRIMARY KEY (ORDER_ID);",
            "ALTER TABLE DIM_PRODUCTS ADD CONSTRAINT PK_DIM_PRODUCTS PRIMARY KEY (PRODUCT_ID);",
            "ALTER TABLE DIM_DAY ADD CONSTRAINT PK_DIM_DAY PRIMARY KEY (DAY_ID);",
            "ALTER TABLE FACT_ORDERS ADD CONSTRAINT FK_FACT_ORDERS_DAY FOREIGN KEY (DAY_ID) REFERENCES DIM_DAY (DAY_ID);",
            "ALTER TABLE FACT_ORDER_PRODUCTS ADD CONSTRAINT FK_FACT_ORDER_PRODUCTS_ORDER FOREIGN KEY (ORDER_ID) REFERENCES FACT_ORDERS (ORDER_ID);",
            "ALTER TABLE FACT_ORDER_PRODUCTS ADD CONSTRAINT FK_FACT_ORDER_PRODUCTS_PRODUCT FOREIGN KEY (PRODUCT_ID) REFERENCES DIM_PRODUCTS (PRODUCT_ID);"
        ]
        loader.execute("USE SCHEMA CLEAN")
        loader.execute("USE ROLE PLOMERO")
        for sql in sentencias_sql:
            loader.execute(sql)
        loader.commit()

    return nuevas_tablas
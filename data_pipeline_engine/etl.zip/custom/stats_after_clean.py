if 'custom' not in globals():
    from mage_ai.data_preparation.decorators import custom
if 'test' not in globals():
    from mage_ai.data_preparation.decorators import test

import pandas as pd
def analisis_exploratorio_simple(nombre_tabla, df):
    df = df.copy()

    for col in df.select_dtypes(include=['object']).columns:
        df[col] = df[col].apply(lambda x: x.lower().strip() if pd.notna(x) else x)

    stats = {
        "nombre_tabla": nombre_tabla,
        "dimensiones": df.shape,
        "columnas": {}
    }
    
    for col in df.columns:
        valores_unicos = df[col].nunique(dropna=True)
        tipos_datos = [str(t) for t in df[col].apply(type).unique()]
        nulos = int(df[col].isnull().sum())
        duplicados_unicos = int(((df[col].duplicated(keep='first')) & (df[col].notnull())).sum())
        duplicados_totales = int(((df[col].duplicated(keep=False)) & (df[col].notnull())).sum())
        
        stats["columnas"][col] = {
            "valores_unicos": valores_unicos,
            "tipos_datos": tipos_datos,
            "nulos": nulos,
            "duplicados_unicos": duplicados_unicos,
            "duplicados_totales": duplicados_totales,
        }
    
    separador = "=" * 50
    print(separador)
    print(f"Análisis de la tabla: {stats['nombre_tabla']}")
    print(f"Dimensiones: {stats['dimensiones']}")
    print(separador)
    print("Estadísticas por columna:")
    for col, col_stats in stats["columnas"].items():
        print(f"\nColumna: {col}")
        for key, value in col_stats.items():
            print(f"  {key}: {value}")
    print(separador)
    
    return stats

@custom
def transform_custom(dfs: list, *args, **kwargs) -> list:
    """
    args: The output from any upstream parent blocks (if applicable)

    Returns:
        Anything (e.g. data frame, dictionary, array, int, str, etc.)
    """
    tables = kwargs['tables'] 
    for table_name, df in zip(tables, dfs):
        analisis_exploratorio_simple(table_name, df)

    return dfs


@test
def test_output(output, *args) -> None:
    """
    Template code for testing the output of the block.
    """
    assert output is not None, 'The output is undefined'
